# ConVista-Generic-Tile
A Fiori Tile which renders arbitrary UI5 content, which can be defined by the tile configurator
